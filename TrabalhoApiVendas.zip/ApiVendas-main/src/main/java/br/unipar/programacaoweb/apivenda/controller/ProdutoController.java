package br.unipar.programacaoweb.apivenda.controller;


import br.unipar.programacaoweb.apivenda.model.Produto;
import br.unipar.programacaoweb.apivenda.service.ProdutoService;

import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/produto")
public class ProdutoController {

    @Inject
    private ProdutoService produtoService;

    @POST
    @Consumes(value = MediaType.APPLICATION_JSON)
    @Produces(value = MediaType.APPLICATION_JSON)
    public Response cadastrarProduto(Produto produto) {
        try {
            produtoService.cadastrarProdutos(produto);
            return Response.status(201).entity("Produtos Cadastrados com exito").build();
        } catch (Exception ex) {
            return Response.status(403).entity(ex.getMessage()).build();
        }
    }

    @GET
    @Produces(value = MediaType.APPLICATION_JSON)
    public Response getProdutos() {
        try {
            return Response.ok(produtoService.getProdutos())
                    .build();
        } catch (Exception ex) {
            return Response.status(403).entity(ex.getMessage()).build();
        }
    }


    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateProduto(Produto produto
    ) {
        try {
            produtoService.updateProdutos(produto);
            return Response.status(Response.Status.CREATED)
                    .entity("Produtos atualizadoa com sucesso")
                    .build();
        } catch (Exception ex) {
            return Response.status(Response.Status.FORBIDDEN)
                    .entity(ex.getMessage())
                    .build();
        }
    }

    @DELETE
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response deleteProduto(Produto produto) {
        try {
            produtoService.deleteProdutos(produto.getId());
            return Response.status(Response.Status.OK)
                    .entity("Produto deletado com sucesso")
                    .build();
        } catch (Exception ex) {
            return Response.status(Response.Status.FORBIDDEN)
                    .entity(ex.getMessage())
                    .build();
        }
    }


}

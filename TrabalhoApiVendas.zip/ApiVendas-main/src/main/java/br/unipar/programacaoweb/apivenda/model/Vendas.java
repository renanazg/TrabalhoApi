package br.unipar.programacaoweb.apivenda.model;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Entity
@Getter
@Setter
public class Vendas {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(length = 110)
    private BigDecimal total;

    @Column(length = 30)
    private String observacoes;

    @Column(length = 30)
    private Integer fk_cliente_id;

}

package br.unipar.programacaoweb.apivenda.service;


import br.unipar.programacaoweb.apivenda.model.Produto;
import br.unipar.programacaoweb.apivenda.repository.ProdutoRepository;

import jakarta.ejb.Stateless;
import jakarta.inject.Inject;

import java.util.List;

@Stateless

public class ProdutoService {

    @Inject
    private ProdutoRepository produtoRepository;

    public void cadastrarProdutos(Produto produto) throws Exception {
        produtoRepository.cadastrarProdutos(produto);
    }

    public List<Produto> getProdutos() {
        return produtoRepository.getProdutos();
    }

    public void updateProdutos(Produto produto) throws Exception{
        produtoRepository.updateProdutos(produto);
    }

    public void deleteProdutos(Integer id){
        produtoRepository.deleteProdutos(id);
    }


}

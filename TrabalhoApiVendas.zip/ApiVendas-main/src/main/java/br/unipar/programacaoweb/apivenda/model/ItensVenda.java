package br.unipar.programacaoweb.apivenda.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Entity
@Getter
@Setter
public class ItensVenda {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(length = 90)
    private BigDecimal vl_unitario;

    @Column(length = 25)
    private BigDecimal vl_total;

    @Column(length = 25)
    private BigDecimal quant;

    @Column(length = 25)
    private Integer fk_produto_id;

    @Column(length = 25)
    private Integer fk_Venda_id;

}

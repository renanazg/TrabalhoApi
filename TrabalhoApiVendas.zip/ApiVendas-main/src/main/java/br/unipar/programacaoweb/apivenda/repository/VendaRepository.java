package br.unipar.programacaoweb.apivenda.repository;

import br.unipar.programacaoweb.apivenda.model.Vendas;

import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.UserTransaction;

import java.util.List;

@Stateless

public class VendaRepository {

    @PersistenceContext(unitName = "HibernateMaven")
    private EntityManager em;
    private UserTransaction utx;

    public void cadastrarVenda(Vendas venda) throws Exception {
        try {
            em.persist(venda);
        } catch (Exception ex) {
            throw new Exception("Produto não pode ser cadastrado");
        }
    }

    public List<Vendas> getVendas() {
        String jpql = "SELECT l FROM Vendas l";
        return em.createQuery(jpql, Vendas.class).getResultList();
    }

}
